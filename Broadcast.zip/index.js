const fs = require("fs");
const config = require("./config.json");

const {
  Client,
  GatewayIntentBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  PermissionsBitField,
  Partials,
} = require("discord.js");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildPresences,
  ],
  partials: [Partials.GuildMember],
});

client.once("ready", () => {
  console.log("Bot is Ready!");
  console.log("Code by Haze Studio");
  console.log("discord.gg/https://discord.gg/rQYVz7HuAH");
});

client.on("messageCreate", async (message) => {
  if (!message.content.startsWith("!bc") || message.author.bot) return;


  const member = message.guild.members.cache.get(message.author.id);


  if (
    !message.member.permissions.has(PermissionsBitField.Flags.Administrator)
  ) {
    return message.reply({
      content: "You dont have permssion",
      ephemeral: true,
    });
  }

  const embed = new EmbedBuilder()
    .setColor("#0099ff")
    .setTitle("Broadcast")
    .setImage(config.image)
    .setDescription("Who Do You Want To Broadcast?");

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("send_all")
    .setLabel("Send To ALL Memmbers")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId("send_online")
    .setLabel("Send To online Memmbers")
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId("send_offline")
      .setLabel("Send To Offline Memmbers")
      .setStyle(ButtonStyle.Danger),
  );

  await message.reply({
    embeds: [embed],
    components: [row],
    ephemeral: true,
  });
});

client.on("interactionCreate", async (interaction) => {
  try {
    if (interaction.isButton()) {
      let customId;
      if (interaction.customId === "send_all") {
        customId = "modal_all";
      } else if (interaction.customId === "send_online") {
        customId = "modal_online";
      } else if (interaction.customId === "send_offline") {
        customId = "modal_offline";
      }

      const modal = new ModalBuilder()
        .setCustomId(customId)
        .setTitle("Type your message");

      const messageInput = new TextInputBuilder()
        .setCustomId("messageInput")
        .setLabel("Write Your Message")
        .setStyle(TextInputStyle.Paragraph);

      modal.addComponents(new ActionRowBuilder().addComponents(messageInput));

      await interaction.showModal(modal);
    }

    if (interaction.isModalSubmit()) {
      const message = interaction.fields.getTextInputValue("messageInput");

      const guild = interaction.guild;
      if (!guild) return;

      await interaction.deferReply({
        ephemeral: true,
      });
      if (interaction.customId === "modal_all") {
        const membersToSend = guild.members.cache.filter(
          (member) => !member.user.bot,
        );
        await Promise.all(
          membersToSend.map(async (member) => {
            try {
              await member.send({
                content: `${message}\n<@${member.user.id}>`,
                allowedMentions: { parse: ["users"] },
              });
            } catch (error) {
              console.error(
                `Error sending message to ${member.user.tag}:`,
                error,
              );
            }
          }),
        );
      } else if (interaction.customId === "modal_online") {
        const onlineMembersToSend = guild.members.cache.filter(
          (member) =>
            !member.user.bot &&
            member.presence &&
            member.presence.status !== "offline",
        );
        await Promise.all(
          onlineMembersToSend.map(async (member) => {
            try {
              await member.send({
                content: `${message}\n<@${member.user.id}>`,
                allowedMentions: { parse: ["users"] },
              });
            } catch (error) {
              console.error(
                `Error sending message to ${member.user.tag}:`,
                error,
              );
            }
          }),
        );
      } else if (interaction.customId === "modal_offline") {
        const offlineMembersToSend = guild.members.cache.filter(
          (member) =>
            !member.user.bot &&
            (!member.presence || member.presence.status === "offline"),
        );
        await Promise.all(
          offlineMembersToSend.map(async (member) => {
            try {
              await member.send({
                content: `${message}\n<@${member.user.id}>`,
                allowedMentions: { parse: ["users"] },
              });
            } catch (error) {
              console.error(
                `Error sending message to ${member.user.tag}:`,
                error,
              );
            }
          }),
        );
      }
      await interaction.editReply({
        content: "Message Sent To All Memmbers",
      });
    }
  } catch (error) {
    console.error("Error in interactionCreate event:", error);
  }
});


client.login(process.env.TOKEN);
